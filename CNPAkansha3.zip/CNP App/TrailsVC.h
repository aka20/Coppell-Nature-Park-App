//
//  TrailsVC.h
//  CNP App
//
//  Created by Akansha Singh on 11/19/19.
//  Copyright © 2019 Akansha Singh. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TrailsVC : NSObject

@end

NS_ASSUME_NONNULL_END
