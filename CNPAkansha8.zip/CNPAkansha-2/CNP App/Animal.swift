//
//  Animal.swift
//  CNP App
//
//  Created by Akansha Singh on 1/24/20.
//  Copyright © 2020 Akansha Singh. All rights reserved.
//

import UIKit

class Animal {
    
    // MARK: Properties
    
    var name: String = ""
    var photo: UIImage?
    
    // MARK: Initialization

    init?(name:String, photo: UIImage?) {
        
        // Initialize stored properties
        
        self.name = name
        self.photo = photo
        
        return nil
        
    }
    
   
    
  
}



