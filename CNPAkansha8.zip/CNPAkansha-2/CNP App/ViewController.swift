//
//  ViewController.swift
//  CNP App
//
//  Created by Akansha Singh on 11/15/19.
//  Copyright © 2019 Akansha Singh. All rights reserved.
//

import UIKit

private let reuseIdentifier = "DropDownCell"

class ViewController: UIViewController {
    
    
    // MARK - properties
    
    var tableView: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        
      
    }
}
