//
//  NewsTableView.swift
//  CNP App
//
//  Created by Akansha Singh on 1/30/20.
//  Copyright © 2020 Akansha Singh. All rights reserved.
//

import UIKit


    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    


