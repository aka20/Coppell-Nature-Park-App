//
//  AnimalListViewController.swift
//  CNP App
//
//  Created by Akansha Singh on 1/25/20.
//  Copyright © 2020 Akansha Singh. All rights reserved.
//

import UIKit

class AnimalListTableViewController: UITableViewController {
    
    var Array = [String]()
    
    var Images = [UIImage]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        Array = ["Canada Goose", "Northern Cardinal", "Northern Mockingbird", "American Robin", "Blue Jay", "Dark-Eyed Junco", "Great Egret", "Mallard", "Wood Duck", "Bufflehead", "Ruby-Crowned Kinglet", "Yellow-Rumped Warbler", "Spotted Towhee"]
        
        Images = [UIImage(named: "canadaGoose"), UIImage(named: "northernCardinal"), UIImage(named: "northernMockingbird"), UIImage(named: "americanRobin"), UIImage(named: "blueJay"), UIImage(named: "darkEyedJunco"), UIImage(named: "greatEgret"), UIImage(named: "mallard"), UIImage(named: "woodDuck"), UIImage(named: "bufflehead"), UIImage(named: "rubyKinglet"), UIImage(named: "yellowRumpedWarbler"), UIImage(named: "spottedTowhee")] as! [UIImage]
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Array.count
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        var Cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as UITableViewCell
        
        //  Cell.textLabel?.text = Array[indexPath.row]
        
        Cell.textLabel?.text = Array[indexPath.row]
        Cell.imageView?.image = Images[indexPath.row]
        
        return Cell
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
